package com.backendless.predajelektroniky.data;

import com.backendless.Backendless;
import com.backendless.BackendlessCollection;
import com.backendless.async.callback.AsyncCallback;

import java.util.Map;
import java.util.HashMap;

public class predajElektronikyStoredProcedures
{
}